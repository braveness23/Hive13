                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:3393574
Laundry Detergent Cup Drain - remodeled by peter_v is licensed under the Creative Commons - Attribution - Share Alike license.
http://creativecommons.org/licenses/by-sa/3.0/

# Summary

This was inspired by the original Laundry Detergent Cup Drain and modeled from scratch in Fusion 360. As is, it fits the new Tide bottle, but the model is fully parametric and therefore can be adjusted to fit other detergent brands. It uses 40% less* filament and about the same in printing time than the original.

It has added drain "lip" to prevent leaking back out.

*use Slic3r for additional reduction in filament use. Steps described in Print Settings section.

# Print Settings

Printer Brand: Prusa
Printer: i3 MK3
Rafts: No
Supports: Yes
Resolution: 0.2mm
Infill: 20%
Filament_brand: Amazon Essentials
Filament_color: Black
Filament_material: PETG

Notes: 
The model will print as is, with minimal support if overhang threshold set to 35 degrees or less in slic3r or 65 or more in cura. I printed mine with 15 degrees threshold. Support needs to be set to everywhere due to the position of the cap.

However, for additional plastic savings use Slic3r and:
1. load the model
2. click settings
3. select the model in the new settings window
4. click "split part"
5. now you should see 3 parts listed in the tree
6. select the third part and change the type to "Support Blocker"
(see attached screenshot)